GAPPA - chat app (installable web app)

PHONE MEIN CHALANE KE STEPS
1. Is poore folder ko HTTPS par host karo (sabse aasan: netlify.com/drop par folder drag-drop karo, ya GitHub Pages).
2. Phone ke Chrome mein wo link kholo.
3. Menu (3 dot) -> "Install app" / "Add to Home screen". Ho gaya, ab ye normal app ki tarah chalega.
   (iPhone: Safari -> Share -> Add to Home Screen)

DOSTO KE SAATH CHAT (OPTIONAL)
1. console.firebase.google.com par project banao -> Realtime Database -> Create (test mode).
2. Database ka URL copy karo (https://xxxx-default-rtdb.firebaseio.com).
3. Gappa app -> Settings -> "Firebase database URL" mein paste karo -> Save.
4. Dost bhi wahi URL daale aur wahi room code join kare.
